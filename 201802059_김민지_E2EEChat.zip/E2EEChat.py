import socket
import threading
from AES_256_CBC import AES_256_CBC
import base64

# 서버 연결정보; 자체 서버 실행시 변경 가능
SERVER_HOST = "homework.islab.work"
SERVER_PORT = 8080

connectSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
connectSocket.connect((SERVER_HOST, SERVER_PORT))

global algo, iv, key
global aes_256_cbc
# algo, iv, key 를 전역 변수로 설정 한다.
# aes_256_cbc도 전역 변수로 설정하는데, 암호화를 위한 객체를 생성하기 위함이다.

algo= ""
iv = ""
key = ""
# algo, iv, key 값에 초기 값을 ""로 정의한다.

def socket_read():
    while True:
        readbuff = connectSocket.recv(2048)

        if len(readbuff) == 0:
            continue

        recv_payload = readbuff.decode('utf-8')
        parse_payload(recv_payload)

def socket_send():
    global iv, key
    global aes_256_cbc
    # 전역변수를 사용하기 위함이다.
    while True:
        str = input("MESSAGE: ") # 처음 시작
        if str == '3EPROTO CONNECT': # 서버에 연결
            str += '\n'+input("") # Credential
            send_bytes = str.encode('utf-8')
        elif str == '3EPROTO KEYXCHG': # 키 교환
            str += '\n' + input("") # algo
            str += '\n' + input("") # From
            str += '\n' + input("") # To
            str += '\n' + input("") # Space
            str += '\n'
            key = input("") # key
            str += key
            str += '\n'
            iv = input("") # iv
            str += iv
            aes_256_cbc = AES_256_CBC(key, iv)  # 암호화하기 위한 객체 생성
            send_bytes = str.encode('utf-8')
        elif str == '3EPROTO DISCONNECT':
            str += '\n' + input("")
            send_bytes = str.encode('utf-8')
        elif str == '3EPROTO KEYXCHGOK': # 키 교환 응답
            str += '\n' + input("") # Algo
            str += '\n' + input("") # From
            str += '\n' + input("") # To
            send_bytes = str.encode('utf-8')
        elif str == '3EPROTO KEYXCHGFAIL':# 키 교환 중복 응답
            str += '\n' + input("") # Algo
            str += '\n' + input("") # From
            str += '\n' + input("") # To
            send_bytes = str.encode('utf-8')
        elif str == '3EPROTO MSGSEND':
            str += '\n' + input("") # From
            str += '\n' + input("") # To
            str += '\n' + input("") # Nonce
            str += '\n' + input("") # Space
            str += '\n'
            plain = input("") # Message (plaintext)
            str += aes_256_cbc.encrypt(plain)  # 메시지 암호화
            send_bytes = str.encode('utf-8')
        # 모든 입력에는 '\n' 을 함께 넣어줌으로써 수신되었을 때 '\n' 으로 끊을 수 있게끔 한다.
        connectSocket.sendall(send_bytes)

def parse_payload(payload):
    # 수신된 페이로드를 여기서 처리; 필요할 경우 추가 함수 정의 가능
    # 이 payload 쪼개서 payload가 가지고 있는 정보를 바탕으로 채팅프로그램 작동
    # 개행문자 이용해서 끊기
    encryption_info = payload.split("\n")

    global algo, iv, key
    global aes_256_cbc

    if encryption_info[0] == '3EPROTO KEYXCHG': # 키 교환
        if key != "":  # 키가 초기 값이 아닐 경우, 즉 키 교환 중복 요청되었을 경우
            print('3EPROTO KEYXCHGFAIL')
            print(encryption_info[2]) # FROM
            print(encryption_info[4]) # TimeStamp
            print('\n')
            print('Duplicated Key Exchange Request')
            # 키 교환이 중복되었음을 print해서 알려준다.
        else:
            algo = encryption_info[1] # 알고리즘
            key = encryption_info[6] # 키
            iv = encryption_info[7] # iv
            aes_256_cbc = AES_256_CBC(key, iv)  # 암호화하기 위한 객체 생성
            print(payload)
    elif encryption_info[0] == '3EPROTO MSGRECV': # 메세지 수신
        print('3EPROTO MSGRECV')
        print(encryption_info[2]) # From
        print(encryption_info[3]) # To
        print(encryption_info[1])  # Timestamp
        print(encryption_info[4]) # 공백
        print(aes_256_cbc.decrypt(encryption_info[5])) # 메세지(encryption_info[5]) 복호화
        print('\n')
    elif encryption_info[0] == '3EPROTO KEYXCHGFAIL': # 키 교환 중복 요청
        print(payload)
        print('\n')
        print('Duplicated Key Exchange Request')
        print('\n')
        # 키 교환이 중복되었음을 print 해서 알려준다.
    else:
        print(payload)
    pass

reading_thread = threading.Thread(target=socket_read)
sending_thread = threading.Thread(target=socket_send)

reading_thread.start()
sending_thread.start()

reading_thread.join()
sending_thread.join()