from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import base64

class AES_256_CBC(): # AES-256-CBC

    def __init__(self, key, iv):
        self.key = key.encode('utf-8') # 문자열 인코딩 : utf-8
        self.iv = iv.encode('utf-8') # 문자열 인코딩 : utf-8
        # E2EEChat 에서 입력받은 key 랑 iv 를 인자로 받는다.

    def encrypt(self, plaintext): # 암호화 ( plaintext 를 암호화한다. )
        plaintext = pad(plaintext.encode('utf-8'), AES.block_size)
        #AES.block_size에 맞춰 padding을 수행 한다. 이때 plaintext는 문자열이므로 utf-8로 인코딩한다.
        cipher = AES.new(self.key, AES.MODE_CBC, self.iv)
        # CBC 모드로 암호화 하기 위해 cipher 생성해준다.
        return base64.b64encode(self.iv + cipher.encrypt(plaintext)).decode('utf-8')
        # base64 사용위함, 문자열 인코딩 : utf-8

    def decrypt(self, ciphertext): # 복호화 ( ciphertext 를 복호화한다. )
        ciphertext = base64.b64decode(ciphertext) # base64 사용위함
        cipher = AES.new(self.key, AES.MODE_CBC, self.iv)
        # CBC모드로 복호화 하기 위해 cipher 생성해준다.
        return unpad(cipher.decrypt(ciphertext[AES.block_size:]), AES.block_size).decode('utf-8')
        # ciphertext를 복호화 한 후 unpad를 통해 padding을 넣어준 값들을 떼어내어 원래의 메시지가 출력될 수 있도록 한다.
